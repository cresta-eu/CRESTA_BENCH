// 
// Copyright (C) University College London, 2007-2012, all rights reserved.
// 
// This file is part of HemeLB and is CONFIDENTIAL. You may not work 
// with, install, use, duplicate, modify, redistribute or share this
// file, or any part thereof, other than as allowed by any agreement
// specifically made by you with University College London.
// 

#ifndef HEMELB_FUNCTIONALTESTS_CPPTESTS_EXAMPLE_EXAMPLE_H
#define HEMELB_FUNCTIONALTESTS_CPPTESTS_EXAMPLE_EXAMPLE_H

#include "functionaltests/cpptests/example/ExampleTests.h"


#endif /* HEMELB_FUNCTIONALTESTS_CPPTESTS_EXAMPLE_EXAMPLE_H */
