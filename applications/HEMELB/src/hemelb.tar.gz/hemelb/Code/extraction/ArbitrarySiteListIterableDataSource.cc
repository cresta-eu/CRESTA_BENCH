/*
 * ArbitrarySiteListIterableDataSource.cc
 *
 *  Created on: 3 Jul 2012
 *      Author: derek
 */

#include "extraction/ArbitrarySiteListIterableDataSource.h"

namespace hemelb
{
  namespace extraction
  {
    ArbitrarySiteListIterableDataSource::~ArbitrarySiteListIterableDataSource()
    {

    }
  }
}

