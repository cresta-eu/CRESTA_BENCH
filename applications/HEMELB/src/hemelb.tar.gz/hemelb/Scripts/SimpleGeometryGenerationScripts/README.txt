Run ./four_cube.py to generate the file four_cube.gmy

More details about the geometry in four_cube.py
