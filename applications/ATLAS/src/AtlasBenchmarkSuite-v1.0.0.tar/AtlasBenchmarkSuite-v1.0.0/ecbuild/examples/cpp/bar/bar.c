#include "foo.h"

int bar()
{
  return foo() * foo();
}