#ifndef bar_h
#define bar_h

int bar();

#endif