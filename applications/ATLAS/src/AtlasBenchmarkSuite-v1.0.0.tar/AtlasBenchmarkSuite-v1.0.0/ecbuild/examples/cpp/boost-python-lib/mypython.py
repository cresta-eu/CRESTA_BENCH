"""
API for the C++ module using boost::python

mypython.py:
    This file can be used to do some python actions at import

Module description:
    ...
"""
from libmypython import *