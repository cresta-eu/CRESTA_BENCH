#ifndef foo_h
#define foo_h

int foo();

#endif