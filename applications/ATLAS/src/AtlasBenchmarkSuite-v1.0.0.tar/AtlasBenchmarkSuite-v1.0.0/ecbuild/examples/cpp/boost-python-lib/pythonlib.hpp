#ifndef pythonlib_hpp
#define pythonlib_hpp

#include <boost/python.hpp>

#endif